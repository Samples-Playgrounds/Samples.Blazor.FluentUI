﻿using System;

namespace HybridWebView
{
    partial class HybridWebView
    {
        partial void InitializeHybridWebView()
        {
            throw new PlatformNotSupportedException();
        }
    }
}
