﻿namespace TimeUntilWeb.Client.Services
{
    public class PhotoManager : Root.Services.PhotoManager
    {
        public override void PickPhoto()
        {
            throw new NotImplementedException();
        }
        public override void TakePhoto()
        {
            throw new NotImplementedException();
        }
    }
}
